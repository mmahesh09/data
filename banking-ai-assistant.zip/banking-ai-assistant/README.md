# Banking AI Assistant

ChatGPT-style knowledge assistant for banking metadata — upload Excel, PDF, or Markdown files and query them through a RAG pipeline powered by FAISS + OpenRouter.

## Quick Start

### 1. Install Python dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 2. Set your API key
Edit `backend/.env`:
```
OPENROUTER_API_KEY=your_actual_key_here
OPENROUTER_MODEL=deepseek/deepseek-chat
```
Get a free key at https://openrouter.ai

### 3. Run the backend
```bash
cd backend
uvicorn app:app --reload --port 8000
```

### 4. Open the app
Visit http://localhost:8000

## Usage

1. Click **Upload Document** in the sidebar → select `.xlsx`, `.pdf`, or `.md`
2. Wait for "indexed" confirmation
3. Type your question in the chat box

## Supported File Types
| Extension | Loader |
|-----------|--------|
| `.xlsx` / `.xls` | Pandas — all sheets |
| `.pdf` | PyPDF — all pages |
| `.md` / `.txt` | TextLoader |

## Architecture
```
Upload → Store in uploads/ → Detect type → Load → Chunk (1000 tokens, 200 overlap)
      → SentenceTransformer embeddings → FAISS (merge with existing index)
      → Similarity search (top-5) → OpenRouter LLM → Chat UI
```

## Project Structure
```
banking-ai-assistant/
├── frontend/          # Plain HTML/CSS/JS chat UI
│   ├── index.html
│   ├── style.css
│   └── script.js
└── backend/
    ├── app.py         # FastAPI server
    ├── uploads/       # Uploaded documents land here
    ├── vector_db/     # FAISS index persisted here
    ├── ingestion/     # File loaders + chunker
    ├── rag/           # Embeddings, vectorstore, pipeline
    └── agents/        # metadata_agent, sql_agent, glossary_agent
```
