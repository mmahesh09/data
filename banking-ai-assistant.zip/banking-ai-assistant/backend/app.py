import os
import shutil
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

load_dotenv()

from rag.rag_pipeline import ask_question
from rag.vectorstore import process_new_file

UPLOAD_DIR = "uploads"
ALLOWED_EXTENSIONS = {".xlsx", ".xls", ".md", ".txt", ".pdf"}


@asynccontextmanager
async def lifespan(app: FastAPI):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs("vector_db", exist_ok=True)
    yield


app = FastAPI(title="Banking AI Assistant", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="../frontend"), name="static")


class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    response: str


@app.get("/")
async def home():
    return FileResponse("../frontend/index.html")


@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{ext}'. Allowed: {', '.join(ALLOWED_EXTENSIONS)}",
        )

    filepath = os.path.join(UPLOAD_DIR, file.filename)
    with open(filepath, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        chunk_count = process_new_file(filepath)
    except Exception as e:
        os.remove(filepath)
        raise HTTPException(status_code=500, detail=f"Indexing failed: {str(e)}")

    return {"message": f"File '{file.filename}' uploaded and indexed ({chunk_count} chunks)"}


@app.post("/chat", response_model=ChatResponse)
async def chat(data: ChatRequest):
    if not data.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")
    try:
        response = ask_question(data.message)
    except FileNotFoundError:
        response = "No documents have been indexed yet. Please upload a file first."
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"response": response}


@app.get("/files")
async def list_files():
    if not os.path.exists(UPLOAD_DIR):
        return {"files": []}
    files = [
        f for f in os.listdir(UPLOAD_DIR)
        if os.path.splitext(f)[1].lower() in ALLOWED_EXTENSIONS
    ]
    return {"files": sorted(files)}
