# Banking Metadata Reference Guide

## Core Tables

### CUSTOMER_MASTER
- **customer_id** (VARCHAR 20): Unique customer identifier. Primary key.
- **customer_name** (VARCHAR 100): Full legal name as per KYC documents.
- **cif_number** (VARCHAR 15): Customer Information File number assigned by core banking.
- **segment** (VARCHAR 20): Customer segment — RETAIL, HNI, CORPORATE, SME.
- **onboarding_date** (DATE): Date customer account was activated.
- **kyc_status** (VARCHAR 10): KYC verification status — VERIFIED, PENDING, EXPIRED.
- **risk_rating** (VARCHAR 5): AML risk rating — LOW, MED, HIGH.

### ACCOUNT_MASTER
- **account_number** (VARCHAR 20): Bank account number. Primary key.
- **customer_id** (VARCHAR 20): Foreign key → CUSTOMER_MASTER.customer_id.
- **account_type** (VARCHAR 20): SB (Savings), CA (Current), FD (Fixed Deposit), RD (Recurring Deposit), LOAN.
- **branch_code** (VARCHAR 10): Branch IFSC prefix. Foreign key → BRANCH_MASTER.
- **open_date** (DATE): Account opening date.
- **status** (VARCHAR 10): ACTIVE, DORMANT, CLOSED, FROZEN.
- **currency** (VARCHAR 3): ISO 4217 currency code. Default INR.
- **balance** (DECIMAL 18,2): Current ledger balance.

### TRANSACTION_LOG
- **txn_id** (VARCHAR 30): Unique transaction reference. Primary key.
- **account_number** (VARCHAR 20): Foreign key → ACCOUNT_MASTER.
- **txn_date** (DATETIME): Transaction timestamp (UTC).
- **txn_type** (VARCHAR 10): CR (Credit), DR (Debit).
- **amount** (DECIMAL 18,2): Transaction amount in account currency.
- **channel** (VARCHAR 20): BRANCH, ATM, NEFT, IMPS, RTGS, UPI, NETBANKING, MOBILE.
- **narration** (VARCHAR 255): Transaction description.
- **status** (VARCHAR 10): SUCCESS, FAILED, REVERSED, PENDING.

---

## Glossary

| Term | Definition |
|------|-----------|
| CIF | Customer Information File — master record for a banking customer |
| KYC | Know Your Customer — regulatory identity verification process |
| AML | Anti-Money Laundering — regulatory compliance framework |
| IFSC | Indian Financial System Code — 11-digit bank branch identifier |
| NEFT | National Electronic Funds Transfer — batch settlement payment system |
| RTGS | Real Time Gross Settlement — high-value instant fund transfer |
| IMPS | Immediate Payment Service — 24x7 instant interbank transfer |
| UPI | Unified Payments Interface — mobile-first payment system by NPCI |
| NPCI | National Payments Corporation of India |
| NPA | Non-Performing Asset — loan overdue > 90 days |
| LTV | Loan-to-Value ratio — loan amount vs collateral value |
| DPD | Days Past Due — number of days a payment is overdue |
| EMI | Equated Monthly Installment |
| CIBIL | Credit Information Bureau India Limited — credit bureau |
| CRAR | Capital to Risk-weighted Assets Ratio — Basel III metric |

---

## Regulatory Metadata

### RBI Reporting Fields
- **SLR**: Statutory Liquidity Ratio — 18% of NDTL maintained in govt securities
- **CRR**: Cash Reserve Ratio — 4% of NDTL maintained with RBI
- **NDTL**: Net Demand and Time Liabilities — basis for SLR/CRR calculation
- **LCR**: Liquidity Coverage Ratio — Basel III short-term liquidity metric

### Data Lineage
- Source System: Finacle Core Banking → ETL (nightly batch) → Data Warehouse
- Reporting Layer: DW → OBIEE → RBI XBRL Reports
- Frequency: Daily EOD batch, Intraday for RTGS/IMPS
