from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.documents import Document


def split_docs(documents: list[Document]) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    return splitter.split_documents(documents)
