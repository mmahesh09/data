from langchain_community.document_loaders import TextLoader
from langchain_core.documents import Document


def load_markdown(path: str) -> list[Document]:
    loader = TextLoader(path, encoding="utf-8")
    docs = loader.load()
    for doc in docs:
        doc.metadata["source"] = path
    return docs
