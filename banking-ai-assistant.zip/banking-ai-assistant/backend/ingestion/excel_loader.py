import pandas as pd
from langchain_core.documents import Document


def load_excel(path: str) -> list[Document]:
    xl = pd.ExcelFile(path)
    docs = []

    for sheet_name in xl.sheet_names:
        df = xl.parse(sheet_name).fillna("")

        for _, row in df.iterrows():
            text = "\n".join(f"{col}: {row[col]}" for col in df.columns if str(row[col]).strip())
            if text.strip():
                docs.append(
                    Document(
                        page_content=text,
                        metadata={"source": path, "sheet": sheet_name},
                    )
                )

    return docs
