import os

import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("OPENROUTER_API_KEY", "")
MODEL = os.getenv("OPENROUTER_MODEL", "deepseek/deepseek-chat")
API_URL = "https://openrouter.ai/api/v1/chat/completions"

SYSTEM_PROMPT = """You are a Banking SQL Agent. Given banking metadata context,
generate accurate SQL queries. Always use proper table/column names from the context.
Format SQL with proper indentation. Add brief comments explaining the query."""


def generate_sql(question: str, context: str) -> str:
    if not API_KEY:
        return "Error: OPENROUTER_API_KEY is not set in .env file."

    prompt = f"""Banking schema context:

{context}

Request: {question}

Generate a SQL query based on the schema above. Format it clearly with comments."""

    try:
        response = requests.post(
            API_URL,
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.0,
                "max_tokens": 1024,
            },
            timeout=30,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"Error generating SQL: {str(e)}"
