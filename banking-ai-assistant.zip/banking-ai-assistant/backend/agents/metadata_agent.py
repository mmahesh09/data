import os

import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("OPENROUTER_API_KEY", "")
MODEL = os.getenv("OPENROUTER_MODEL", "deepseek/deepseek-chat")
API_URL = "https://openrouter.ai/api/v1/chat/completions"

SYSTEM_PROMPT = """You are a Banking Metadata Assistant. You help users understand
banking data definitions, field mappings, data lineage, and regulatory metadata.
Answer only from the provided context. If the answer is not in the context,
say: "Information not found in the uploaded documents." Be precise and structured."""


def generate_answer(question: str, context: str) -> str:
    if not API_KEY:
        return "Error: OPENROUTER_API_KEY is not set in .env file."

    prompt = f"""Context from banking documents:

{context}

Question: {question}

Answer based strictly on the context above. Format your answer clearly.
If the information is not available, say: "Information not found in the uploaded documents."
"""

    try:
        response = requests.post(
            API_URL,
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json",
                "HTTP-Referer": "http://localhost:8000",
                "X-Title": "Banking AI Assistant",
            },
            json={
                "model": MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.1,
                "max_tokens": 1024,
            },
            timeout=30,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    except requests.exceptions.Timeout:
        return "Error: Request timed out. Please try again."
    except requests.exceptions.HTTPError as e:
        return f"Error: API request failed ({e.response.status_code}). Check your API key."
    except Exception as e:
        return f"Error generating answer: {str(e)}"
