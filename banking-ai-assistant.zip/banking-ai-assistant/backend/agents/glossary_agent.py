import os

import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("OPENROUTER_API_KEY", "")
MODEL = os.getenv("OPENROUTER_MODEL", "deepseek/deepseek-chat")
API_URL = "https://openrouter.ai/api/v1/chat/completions"

SYSTEM_PROMPT = """You are a Banking Glossary Agent. You provide clear, concise
definitions of banking terms, acronyms, and data fields. Use context from uploaded
documents when available. Definitions should be precise and regulatory-aware."""


def define_term(term: str, context: str) -> str:
    if not API_KEY:
        return "Error: OPENROUTER_API_KEY is not set in .env file."

    prompt = f"""Banking documents context:

{context}

Define the following banking term or acronym: {term}

Provide: 1) Definition, 2) Context in banking/finance, 3) Any related terms from the documents."""

    try:
        response = requests.post(
            API_URL,
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.2,
                "max_tokens": 512,
            },
            timeout=30,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"Error defining term: {str(e)}"
