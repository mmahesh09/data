import os

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

from ingestion.chunker import split_docs
from ingestion.excel_loader import load_excel
from ingestion.markdown_loader import load_markdown
from ingestion.pdf_loader import load_pdf
from rag.embeddings import embeddings

FAISS_PATH = "vector_db/faiss_index"

LOADERS = {
    ".xlsx": load_excel,
    ".xls": load_excel,
    ".md": load_markdown,
    ".txt": load_markdown,
    ".pdf": load_pdf,
}


def process_new_file(filepath: str) -> int:
    ext = os.path.splitext(filepath)[1].lower()
    loader_fn = LOADERS.get(ext)
    if loader_fn is None:
        raise ValueError(f"No loader for extension '{ext}'")

    docs = loader_fn(filepath)
    chunks = split_docs(docs)

    if not chunks:
        raise ValueError("No content could be extracted from the file")

    if os.path.exists(FAISS_PATH):
        db = FAISS.load_local(FAISS_PATH, embeddings, allow_dangerous_deserialization=True)
        db.add_documents(chunks)
    else:
        db = FAISS.from_documents(chunks, embeddings)

    db.save_local(FAISS_PATH)
    return len(chunks)


def load_db() -> FAISS:
    if not os.path.exists(FAISS_PATH):
        raise FileNotFoundError("Vector index not found. Upload a document first.")
    return FAISS.load_local(FAISS_PATH, embeddings, allow_dangerous_deserialization=True)
