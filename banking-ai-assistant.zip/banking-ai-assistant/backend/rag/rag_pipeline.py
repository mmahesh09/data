import os

from agents.metadata_agent import generate_answer
from rag.retriever import retrieve


def ask_question(question: str) -> str:
    docs = retrieve(question, k=5)
    context = "\n\n---\n\n".join(doc.page_content for doc in docs)
    sources = list({doc.metadata.get("source", "unknown") for doc in docs})
    answer = generate_answer(question, context)
    source_note = "\n\n**Sources:** " + ", ".join(os.path.basename(s) for s in sources)
    return answer + source_note
