from langchain_core.documents import Document

from rag.vectorstore import load_db


def retrieve(query: str, k: int = 5) -> list[Document]:
    db = load_db()
    return db.similarity_search(query, k=k)
